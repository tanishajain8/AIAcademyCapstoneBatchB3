Steps To Run the Flask Server
1. Install Miniconda prompt or Anaconda prompt 
2. To Create virtual environment open miniconda prompt or Anaconda prompt and type command: conda create -n flask_sample python=3.6
3. Activate Environment using command: conda activate flask_sample  
4. open the Flask folder and cd to Folder flask_iris using command:cd C:\Users\07ven\Desktop\flask\flask_iris 
5. Type command:pip install -r requirements.txt 
pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org -r requirements.txt

6. run the Flask Server using command:python app.py
7. open server at link:http://127.0.0.1:8000 
8. Enter Sample values and click predict ("sepal length" : 5.1 , "sepal width" : 3.5 , "petal length" : 1.4 , "petal width" : 0.2)
 
