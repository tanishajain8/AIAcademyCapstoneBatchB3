from flask import Flask,render_template,request,redirect
from flask_cors import CORS,cross_origin
import pickle
import pandas as pd
import numpy as np

app=Flask(__name__)
cors=CORS(app)
model=pickle.load(open('model\RegressionModel.pkl','rb'))
car=pd.read_csv('Cleaned_Car_Data.csv')

@app.route('/',methods=['GET','POST'])
def index():
    companies=sorted(car['brand'].unique())
    car_models=sorted(car['name'].unique())
    year=sorted(car['year'].unique(),reverse=True)
    fuel_type=car['fuel'].unique()
    seller = sorted(car['seller_type'].unique())
    tranmission= sorted(car['transmission'].unique())
    owner= sorted(car['owner'].unique())
    region = sorted(car['region'].unique())
    city = sorted(car['City'].unique())
    state = sorted(car['State or Province'].unique())
    sold = car['sold'].unique()


    companies.insert(0,'Select Company')
    return render_template('index.html',companies=companies, car_models=car_models, years=year,fuel_types=fuel_type,sellers = seller, regions=region, tranmissions=tranmission, owners=owner, cities=city, states=state, solds=sold )


@app.route('/predict',methods=['POST'])
@cross_origin()
def predict():

    
    company=request.form.get('company')

    car_model=request.form.get('car_models')
    year=request.form.get('year')
    fuel_type=request.form.get('fuel_type')
    driven=request.form.get('km_driven')
    owner=request.form.get('owner')
    seller = request.form.get('seller')
    tranmission=request.form.get('tranmission')
    max_power =request.form.get('max_power')
    mileage = request.form.get('mileage')
    engine = request.form.get('engine')
    seats= request.form.get('seats')
    region = request.form.get('region')
    city = request.form.get('city')
    state = request.form.get('state')
    sold = request.form.get('sold')
    

    prediction=model.predict(pd.DataFrame(columns=['name','brand','year','km_driven','fuel','State or Province','City','region','seller_type','transmission','owner','sold','mileage','engine','max_power','seats'],
                              data=np.array([car_model,company,year,driven,fuel_type,state,city,region,seller,tranmission,owner,sold,mileage,engine,max_power,seats]).reshape(1,16)))
    print(prediction)

    return str(np.round(prediction[0],2))



if __name__=='__main__':
    app.run()